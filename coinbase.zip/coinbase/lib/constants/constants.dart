import 'package:flutter/material.dart';

const backgroundColor = Color(0xff0e0e10);

const secondaryColor = Color(0xff141518);

const buttonColor = Color(0xff3b73f8);
