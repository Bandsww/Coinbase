package com.example.coinbase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
